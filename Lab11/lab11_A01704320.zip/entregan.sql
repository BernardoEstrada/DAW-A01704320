BULK INSERT a1704320.a1704320.[Entregan]
   FROM 'e:\wwwroot\a1704320\entregan.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
